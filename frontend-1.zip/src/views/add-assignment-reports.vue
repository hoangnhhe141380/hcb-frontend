<template>
    <div class="panel mx-auto">
        <div class="flex items-center justify-between mb-5 text-center">
            <h3 class="font-semibold text-2xl dark:text-white-light mx-auto">Nhận xét bài làm học sinh</h3>
        </div>
        <div class="mb-5">
            <flat-pickr @input="getStudents" v-model="today" class="form-input text-center w-1/6"></flat-pickr>
        </div>
        <h5 class="text-red-600">Lưu ý: Các trường nhập link Google Drive phải dưới dạng <span
                class="italic font-semibold">https://drive.google.com/file/</span> hoặc <span
                class="italic font-semibold">https://drive.google.com/open?id=</span></h5>
        <div class="cards-container w-full">
            <form @submit.prevent="sendData" class="flex flex-col">
                <div v-for="(student, index) in students" :key="student.studentId"
                    class="flex flex-row w-10/12 bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
                    <div class="border-r-2 name">{{ student.fullName }}</div>
                    <div class="border-r-2 in-class">
                        <label>Link đề bài</label>
                    </div>
                    <div class="border-r-2 homework">asdfsafsf</div>
                </div>



                <button type="submit" class="btn btn-primary mt-6 w-1/3 mx-auto">Xác nhận</button>
            </form>
        </div>
    </div>
</template>
<script setup lang="ts">
import { useRoute } from "vue-router";
import flatPickr from 'vue-flatpickr-component';
import 'flatpickr/dist/flatpickr.css';
import axios from 'axios';
import { ref, onMounted, computed } from 'vue';
import Swal from 'sweetalert2';

let today = ref();


const students = ref([]);

async function sendData() {
    let day = today.value.split('-')[2];
    let month = today.value.split('-')[1];
    let year = today.value.split('-')[0];

    const apiUrl = import.meta.env.VITE_APP_API_URL + `admin/reports/assignment`;

    const data = students.value.map((item) => ({
        studentId: item.studentId,
        date: year + '-' + month + '-' + day,
        homeworkCorrectAnswers: Number(item.homeworkCorrectAnswers) || 0,
        homeworkAnswers: Number(item.homeworkAnswers) || 0,
        homeworkTotalQuestions: Number(item.homeworkTotalQuestions) || 0,
        homeworkUrl: item.homeworkUrl,
        homeworkComment: item.homeworkComment,
        classworkCorrectAnswers: Number(item.classworkCorrectAnswers) || 0,
        classworkAnswers: Number(item.classworkAnswers) || 0,
        classworkTotalQuestions: Number(item.classworkTotalQuestions) || 0,
        classworkUrl: item.classworkUrl,
        classworkComment: item.classworkComment,
        classworkWorksheetUrl: item.classworkWorksheetUrl,
        classworkSolutionUrl: item.classworkSolutionUrl,
    }));

    try {

        const response = await axios.post(apiUrl, data);

        if (response.data.status.displayMessage === "Success.") {
            showSuccessAlert();
        }
    }
    catch (error) {
        // Handle errors (e.g., display error message, retry logic)
        showFailureAlert();
    }

}

function getStudents() {
    students.value = [];
    let day = today.value.split('-')[2];
    let month = today.value.split('-')[1];
    let year = today.value.split('-')[0];
    const apiUrl = import.meta.env.VITE_APP_API_URL + `admin/attendances?date=${day}-${month}-${year}`;

    axios
        .get(apiUrl)
        .then(response => {
            let data = response.data.data;
            if (data.length == 0)
                students.value = [];
            data.forEach(item => {
                const student = {
                    studentId: item.studentId,
                    fullName: item.fullName,
                    hasAssignmentReport: item.hasAssignmentReport
                };
                students.value.push(student);
            });
        });

}

const showFailureAlert = async () => {
    Swal.fire({
        icon: 'error',
        title: 'Đã có lỗi xảy ra',
        padding: '2em',
        customClass: 'sweet-alerts',
    });
}

const showSuccessAlert = async () => {
    Swal.fire({
        icon: 'success',
        title: 'Gửi nhận xét thành công',
        padding: '2em',
        customClass: 'sweet-alerts',
    });
}


</script>