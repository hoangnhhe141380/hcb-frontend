<template>
    <div>
        <div class="panel pb-0 mt-6">
            <div class="flex md:items-center md:flex-row flex-col mb-5 gap-5">
                <button type="button" class="btn btn-success">
                    <router-link to="/lessons/add">{{ $t('Thêm')
                    }}</router-link>
                </button>
                <div class="ltr:ml-auto rtl:mr-auto">
                    <input v-model="search" type="text" class="form-input w-auto" placeholder="Tìm theo tên" />
                </div>
            </div>
            <div class="datatable">
                <vue3-datatable :rows="rows" :columns="cols" :totalRows="rows?.length" :search="search" :sortable="true"
                    skin="whitespace-nowrap bh-table-hover"
                    firstArrow='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-4.5 h-4.5 rtl:rotate-180"> <path d="M13 19L7 12L13 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path opacity="0.5" d="M16.9998 19L10.9998 12L16.9998 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>'
                    lastArrow='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-4.5 h-4.5 rtl:rotate-180"> <path d="M11 19L17 12L11 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path opacity="0.5" d="M6.99976 19L12.9998 12L6.99976 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg> '
                    previousArrow='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-4.5 h-4.5 rtl:rotate-180"> <path d="M15 5L9 12L15 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>'
                    nextArrow='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-4.5 h-4.5 rtl:rotate-180"> <path d="M9 5L15 12L9 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>'>
                    <template #url="data">
                        <a v-bind:href="data.value.url" class="text-primary hover:underline">{{ data.value.url }}</a>
                    </template>
                    <template #details="data">
                        <!-- <router-link :to="{ name: 'lesson', params: { id: data.value.id } }"
                            class="text-primary hover:underline">
                            Chi tiết
                        </router-link> -->
                    </template>
                </vue3-datatable>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import Vue3Datatable from '@bhplugin/vue3-datatable';
import axios from 'axios';
import { useAppStore } from '@/stores/index';
import { useMeta } from '@/composables/use-meta';

useMeta({ title: 'Bài học' });
const search = ref('');
const cols =
    ref([
        { field: 'no', title: 'STT', isUnique: true },
        { field: 'name', title: 'Tên bài học' },
        { field: 'grade', title: 'Lớp' },
        { field: 'url', title: 'Link' },
        { field: 'details', title: 'Thông tin chi tiết' },
    ]) || [];


const rows = ref(
    [
    ] || []
);

const fetchData = () => {

    const apiUrl = import.meta.env.VITE_APP_API_URL + 'admin/lessons';
    axios.get(apiUrl)
        .then((response) => {
            const data = response.data.data;

            const mappedData = data.map((item, index) => ({
                no: index + 1,
                name: item.name,
                grade: item.grade,
                url: "https://www.youtube.com/watch?v=" + item.url,
                id: item.id
            }));

            rows.value = mappedData;

        })
        .catch((error) => {
            console.error('Error fetching data:', error);
        });
};

fetchData();
</script>
