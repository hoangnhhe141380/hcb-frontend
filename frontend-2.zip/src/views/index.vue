<template>
    <div>
        Trang chủ
    </div>
</template>
<script lang="ts" setup>
import { ref, computed } from 'vue';

</script>
